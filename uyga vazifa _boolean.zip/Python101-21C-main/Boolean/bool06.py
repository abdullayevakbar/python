def check_even_digit(b):
	return b%2==0