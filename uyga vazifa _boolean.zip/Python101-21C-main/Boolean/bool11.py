def sum_digits_check_odd(n):
	return (n%10+n//10)%2==1