def check_even_two_digits(a,b):
    x = bool(0 == b%2)
    y = bool(0== a%2)
    z = bool(x == y)
    return bool(z)