def check_to_digit(a):
	return a==7