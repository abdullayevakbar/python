def check_to_digits(a,b):
	return a==b