def check_odd_digit(a):
	return a%2==1