def check_to_positive(b):
	return b>0