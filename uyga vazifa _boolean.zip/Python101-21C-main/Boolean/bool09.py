def check_negative_two_digits(a,b):
    x = bool(0 > b)
    y = bool(0 > a)
    z = bool(x == y)
    return bool(z)