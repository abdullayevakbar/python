def check_range_two_digits(a,b,c):
    x=bool(a<b)
    y=bool(b<c)
    z=bool(x==y)
    return bool(z)