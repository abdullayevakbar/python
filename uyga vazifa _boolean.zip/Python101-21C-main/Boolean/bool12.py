def sum_digits_check_even(n):
	return (n%10+n//10)%2==0