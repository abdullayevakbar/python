def check_to_negative(a):
	return a<0