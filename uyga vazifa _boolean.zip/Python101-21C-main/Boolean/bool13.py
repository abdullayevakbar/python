def two_digit_number_check(n):
	return (n%10+n//10)//10>0