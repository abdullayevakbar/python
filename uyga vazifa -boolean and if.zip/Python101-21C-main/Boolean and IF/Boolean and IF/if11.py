def if_shop_check_pupile(price, on_break):
    if(price>=20) and (on_break==1):
        return True
    return False