def if_check_positive_number_1(a):
    if(a>0):
        a+=1
    else:
        a-=2
    return a