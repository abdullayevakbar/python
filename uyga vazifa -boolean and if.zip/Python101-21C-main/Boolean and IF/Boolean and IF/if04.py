def if_find_min_number(a,b,c):
    x=a
    if(x<b):
        x=b
    if(x<c):
        x=c
    return x