def if_check_positive_number(a):
    if(a>0):
        a+=1
    return a