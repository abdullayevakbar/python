def check_two_digit_number(a):
    b=(a//10)>0 and (a//100)==0
    return b