def check_number_one_add(a,b):
    x=(a%2==1)
    y=(b%2==1)
    return x+y>0
