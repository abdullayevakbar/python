def if_positive_number_count(a,b,c):
    x=0
    x+=(a>0)
    x+=(b>0)
    x+=(c>0)
    return x