def check_two_digit_number_same(a):
    b=(a%10==a//10)
    return b