from math import sqrt ,pow ,pi , tan
x=float(input())
print(round(2*tan(x+pi/2),3))