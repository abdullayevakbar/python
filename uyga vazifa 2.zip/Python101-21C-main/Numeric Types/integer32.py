from math import sqrt ,pow ,pi , tan, cos, sin ,e
x=float(input())
ans=sqrt(sqrt(x+2)+sqrt(x+24)+pow(x,5))
print(round(ans,2))