from math import sqrt ,pow
n=int(input())
print(n//60)