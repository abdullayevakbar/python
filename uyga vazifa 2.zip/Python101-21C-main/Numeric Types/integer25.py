from math import sqrt ,pow ,pi , tan, cos, sin
x=float(input())
ans=pow(sin(x+2)+2,1/3)
print(round(ans,2))