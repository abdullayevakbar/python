def if_largest_user(user_1,user_2,user_3):
    s = 2021 - user_1
    if (2021 - user_2 > s):
        s = 2021 - user_2
    if (2021 - user_2 > s):
        s = 2021 - user_3
    return s