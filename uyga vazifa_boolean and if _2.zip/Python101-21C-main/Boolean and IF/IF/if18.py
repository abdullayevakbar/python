def if_find_idx(a,b,c):
    if(a!=b and a!=c):
        return 1
    if(b!=a and b!=c):
        return 2
    return 3