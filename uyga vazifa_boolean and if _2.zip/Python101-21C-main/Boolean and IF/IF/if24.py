def if_middle_ages_user(user_1,user_2,user_3):
    s = 2021 - user_1
    s += 2021 - user_2
    s += 2021 - user_3
    return s//3