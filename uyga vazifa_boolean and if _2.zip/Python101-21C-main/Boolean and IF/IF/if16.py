def if_certificate_age(age):
	return (18<=age)