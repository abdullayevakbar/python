# a o'zgaruvchiga 7 ni taminlang;
# b o'zgaruvchiga 3 ni taminlang;
# a va b o'zgaruvchilar ayirmasini chop eting;

a = 7
b = 3
print(a-b)