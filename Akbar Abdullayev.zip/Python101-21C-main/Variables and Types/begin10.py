# a o'zgaruvchiga 5 ni taminlang;
# b o'zgaruvchiga 4 ni taminlang;
# c o'zgaruvchiga 2 ni taminlang;
# d o'zgaruvchiga 8 ni taminlang;
# K =  2 * ((a * b) - (c * d));
# Natijani chop eting;


a = 5
b = 4
c = 2
d = 8
K =  2 * ((a * b) - (c * d))
print(K)