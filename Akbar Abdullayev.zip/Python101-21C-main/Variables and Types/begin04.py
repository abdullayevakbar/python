# a o'zgaruvchiga 12 ni taminlang;
# b o'zgaruvchiga 3 ni taminlang;
# a ni b ga bo'lgandagi natijani chop eting;

a = 12
b = 3
print(a/b)