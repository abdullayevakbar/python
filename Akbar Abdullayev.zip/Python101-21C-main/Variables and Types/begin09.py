# a o'zgaruvchiga 8 ni taminlang;
# b o'zgaruvchiga 3 ni taminlang;
# c o'zgaruvchiga 2 ni taminlang;
# d o'zgaruvchiga 4 ni taminlang;
# K =  a + b - c * d;
# Natijani chop eting;

a = 8
b = 3
c = 2
d = 4
K =  a + b - c * d
print(K)