# a o'zgaruvchiga 5 ni taminlang;
# b o'zgaruvchiga 4 ni taminlang;
# c o'zgaruvchiga 8 ni taminlang;
# Quyidagi ifodani natijaga chop eting;
# ifoda: (2*a/b)*c

a = 5
b = 4
c = 8
natija=(2*a/b)*c
print(natija)