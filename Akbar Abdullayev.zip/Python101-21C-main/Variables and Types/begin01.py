# num_one o'zgaruvchiga 5 ni taminlang;
# num_two o'zgaruvchiga 4 ni taminlang;
# Yig'indisini chop eting;

num_one = 5
num_two = 4
print(num_one+num_two)