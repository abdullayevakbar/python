# a o'zgaruvchiga 6 ni taminlang;
# b o'zgaruvchiga 8 ni taminlang;
# a va b o'zgaruvchilar ko'paytmasini chop eting;

a = 6
b = 8
print(a*b)