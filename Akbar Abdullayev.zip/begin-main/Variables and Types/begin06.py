# a o'zgaruvchiga 24 ni taminlang;
# b o'zgaruvchiga 3 ni taminlang;
# c o'zgaruvchiga 5 ni taminlang;
# Quyidagi ifodani K ga taminglang;
# K =  a - b + c;
# Natijani chop eting;

a = 24
b = 3
c = 5
K=a-b+c
print(K)