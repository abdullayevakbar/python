# a o'zgaruvchiga 7 ni taminlang;
# b o'zgaruvchiga 3 ni taminlang;
# c o'zgaruvchiga 5 ni taminlang;
# a, b, c o'zgaruvchilar yig'indisini chop eting;

a = 7
b = 3
c = 5
print(a+b+c)