# Python101-21C
Homework for Python foundation course
