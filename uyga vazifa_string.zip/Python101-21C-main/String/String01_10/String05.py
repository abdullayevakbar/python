def find_indexing_one_character(a):
    return a[-2]