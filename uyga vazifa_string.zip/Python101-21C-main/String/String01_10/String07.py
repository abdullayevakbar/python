def first_and_last_character(a):
    return a[0]+a[-1]