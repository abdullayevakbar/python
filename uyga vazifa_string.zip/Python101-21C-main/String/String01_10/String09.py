def sum_variable(a,b):
    return a+b