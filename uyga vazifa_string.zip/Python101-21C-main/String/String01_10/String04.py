def find_indexing_three_character(a):
    return a[0]+a[1]+a[2]