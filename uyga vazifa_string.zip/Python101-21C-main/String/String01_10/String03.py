def find_length_odd_even(a):
    return a[1]