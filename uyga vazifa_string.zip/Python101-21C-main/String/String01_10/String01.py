def find_length(a):
    return len(a)