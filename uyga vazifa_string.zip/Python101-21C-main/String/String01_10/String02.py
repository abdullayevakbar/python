def find_length_odd_even(a):
	return len(a)%2==0