def str_length_collation(a,b):
    return len(a)==len(b)