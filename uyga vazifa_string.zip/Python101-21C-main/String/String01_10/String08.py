def addition_number(a):
    s=int(a)
    return s+8