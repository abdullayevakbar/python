def func_no_param5():
    a=True
    return type(a)
print(func_no_param5())