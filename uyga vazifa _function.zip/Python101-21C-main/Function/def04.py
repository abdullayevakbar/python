def func_no_param4():
    a=2021
    return type(a)
print(func_no_param4())