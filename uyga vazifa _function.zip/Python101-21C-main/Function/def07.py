def func_hi():
    return "Hello, World!"
print(func_hi())