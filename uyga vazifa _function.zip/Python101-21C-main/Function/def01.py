def func_no_param1():
    return 0
print(func_no_param1())