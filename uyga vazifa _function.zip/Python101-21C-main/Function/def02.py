def func_no_param2():
    return type(0.0)
print(func_no_param2())