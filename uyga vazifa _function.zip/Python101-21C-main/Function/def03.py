def func_no_param3():
    a='Akbar Abdullayev'
    return type(a)
print(func_no_param3())