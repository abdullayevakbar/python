from  math import  pi
def func(x):
    s=0
    if(x%2==0):
        s+=x%10
    x//=10
    if (x % 2 == 0):
        s += x % 10
    x //= 10
    if (x % 2 == 0):
        s += x % 10
    x //= 10
    if (x % 2 == 0):
        s += x % 10
    x //= 10
    if (x % 2 == 0):
        s += x % 10
    return s
a=int(input())
print(func(a))