from  math import  pi
def func_pi():
    return round(pi,5)
print(func_pi())