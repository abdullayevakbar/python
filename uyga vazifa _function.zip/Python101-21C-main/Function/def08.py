def func_hi():
    return "codeschooluz"
print(func_hi())