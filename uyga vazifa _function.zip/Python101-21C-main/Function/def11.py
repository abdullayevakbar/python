from  math import  pi
def func(x):
    s=x//10+x%10
    return s
a=int(input())
print(func(a))