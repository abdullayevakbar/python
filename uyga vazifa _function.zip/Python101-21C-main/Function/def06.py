def func_no_param6(x):
    x+=1
    return x
a=int(input())
print(func_no_param6(a))