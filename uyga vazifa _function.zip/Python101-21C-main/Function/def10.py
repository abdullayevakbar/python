from  math import  pi
def func_pi10():
    return round(pi,10)
print(func_pi10())