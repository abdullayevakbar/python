n=int(input())
ans=pow((n+3)/2,2)
print(ans)
