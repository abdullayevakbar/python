n,x=map(int,input().split())
ans=pow(n,x)+pow(6,x)
print(ans)