x,y=map(int,input().split())
ans=pow(x,4)+5*pow(x,2)+pow(x,3)*y
print(ans)