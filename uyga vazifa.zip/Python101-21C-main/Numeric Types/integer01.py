from math import sqrt

a,b=map(int,input().split())
print(sqrt(sqrt(2*a**3)))