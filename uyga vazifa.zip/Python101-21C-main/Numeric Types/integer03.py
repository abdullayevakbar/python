n=int(input())
a=n//100
b=(n%100)//10
c=n%10
n=c*100+b*10+a;
print(n)
