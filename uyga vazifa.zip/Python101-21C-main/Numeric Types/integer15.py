n=int(input())
print(abs(n))