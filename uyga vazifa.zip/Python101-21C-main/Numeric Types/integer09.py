from math import sin
a=float(input())
print(sin(a))