from math import cos
a=float(input())
print(cos(a))