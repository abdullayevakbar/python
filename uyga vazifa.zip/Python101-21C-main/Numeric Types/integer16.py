n=float(input())
print(round(n,2))