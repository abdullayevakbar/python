import math
a,b=map(int,input().split())
ans=(1/6*math.sqrt(a)+1/3*math.sqrt(b))**2
print(ans)