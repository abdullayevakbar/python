x,y=map(int,input().split())
ans=pow(x,3)*pow(y,5)*6+4*pow(x*y,3)*x-24*x*y
print(ans)