n=int(input())
a=n//100
b=(n%100)//10
c=n%10
print(a+b+c,a*b*c)
