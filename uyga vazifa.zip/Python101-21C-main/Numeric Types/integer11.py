n=int(input())
a=n//10
b=n%10
print(a+b,a*b)