n=int(input())
a=n//100
b=(n%100)//10
c=n%10
n=c+b*100+a*10;
print(n)
