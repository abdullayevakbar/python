from math import sqrt ,pow
n=int(input())
print(2*pow(n+3,2))